exports.users = [
  {
    id: 1,
    name: "Anna",
    age: 24,
    gender: "kobieta",
    location: "Warszawa"
  },
  {
    id: 2,
    name: "Piotr",
    age: 32,
    gender: "mężczyzna",
    location: "Kraków"
  },
  {
    id: 3,
    name: "Kasia",
    age: 28,
    gender: "kobieta",
    location: "Wrocław"
  },
  {
    id: 4,
    name: "Tomasz",
    age: 45,
    gender: "mężczyzna",
    location: "Poznań"
  },
  {
    id: 5,
    name: "Magda",
    age: 30,
    gender: "kobieta",
    location: "Gdańsk"
  },
  {
    id: 6,
    name: "Marcin",
    age: 35,
    gender: "mężczyzna",
    location: "Katowice"
  },
  {
    id: 7,
    name: "Monika",
    age: 27,
    gender: "kobieta",
    location: "Szczecin"
  },
  {
    id: 8,
    name: "Adam",
    age: 29,
    gender: "mężczyzna",
    location: "Łódź"
  },
  {
    id: 9,
    name: "Aleksandra",
    age: 26,
    gender: "kobieta",
    location: "Poznań"
  },
  {
    id: 10,
    name: "Bartosz",
    age: 31,
    gender: "mężczyzna",
    location: "Kraków"
  },
  {
    id: 11,
    name: "Karolina",
    age: 24,
    gender: "kobieta",
    location: "Wrocław"
  }
]